from decimal import Decimal
import pytest
from app.rounding import intelligent_balance, round_to_unit

def test_lines_balance_to_rounded_aggregate():
    independent, balanced, adjustments, total = intelligent_balance([Decimal("1245600"),Decimal("-845300")],Decimal("1000"))
    assert independent == [Decimal("1246000"),Decimal("-845000")]
    assert total == Decimal("400000")
    assert sum(balanced) == total
    assert sum(adjustments) == total - sum(independent)

def test_deterministic_largest_remainder():
    a = intelligent_balance([Decimal("1499"),Decimal("1499"),Decimal("2")],Decimal("1000"))
    b = intelligent_balance([Decimal("1499"),Decimal("1499"),Decimal("2")],Decimal("1000"))
    assert a == b and sum(a[1]) == a[3]

def test_negative_values_balance():
    result = intelligent_balance([Decimal("-1500"),Decimal("-1500"),Decimal("1")],Decimal("1000"))
    assert sum(result[1]) == result[3]

def test_empty_values():
    assert intelligent_balance([],Decimal("1000")) == ([],[],[],Decimal("0"))

def test_zero_unit_rejected():
    with pytest.raises(ValueError):
        round_to_unit(Decimal("2"),Decimal("0"))

def test_half_up():
    assert round_to_unit(Decimal("1250"),Decimal("1000")) == Decimal("1000")
    assert round_to_unit(Decimal("1500"),Decimal("1000")) == Decimal("2000")
