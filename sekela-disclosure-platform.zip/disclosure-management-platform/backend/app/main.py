import csv, io, os
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session, selectinload
from .database import Base, engine, get_db
from .models import Disclosure, DisclosureLine, AuditEvent
from .rounding import intelligent_balance
from .adapters import parse_upload

Base.metadata.create_all(bind=engine)
app = FastAPI(title="SEKELA Disclosure Management API", description="SEKELA by LUSCON — financial disclosure preparation, balancing and workflow.", version="0.2.0")
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:5173").split(","), allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

class DisclosureCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    period: str = Field(min_length=1, max_length=40)
    currency: str = Field(default="ZAR", min_length=3, max_length=3)
    rounding_unit: str = "1000"

class LineCreate(BaseModel):
    account_code: str
    label: str
    source_amount: str
    sort_order: int = 0

class StatusUpdate(BaseModel):
    status: str

def audit(db, did, kind, detail):
    db.add(AuditEvent(disclosure_id=did, event_type=kind, detail=detail))

def line_out(x):
    return {"id":x.id,"account_code":x.account_code,"label":x.label,"source_amount":x.source_amount,
            "independently_rounded":x.independently_rounded,"balanced_amount":x.balanced_amount,
            "adjustment":x.adjustment,"sort_order":x.sort_order}

def disclosure_out(d):
    return {"id":d.id,"name":d.name,"period":d.period,"currency":d.currency,
            "rounding_unit":d.rounding_unit,"status":d.status,"lines":[line_out(x) for x in d.lines]}

@app.get("/health")
def health():
    return {"status":"ok"}

@app.post("/disclosures")
def create_disclosure(payload: DisclosureCreate, db: Session = Depends(get_db)):
    try:
        if Decimal(payload.rounding_unit) <= 0: raise ValueError()
    except (InvalidOperation, ValueError):
        raise HTTPException(422, "rounding_unit must be a positive decimal")
    d = Disclosure(**payload.model_dump())
    db.add(d); db.flush()
    audit(db,d.id,"DISCLOSURE_CREATED",f"Created {d.name} for {d.period}")
    db.commit(); db.refresh(d)
    return disclosure_out(d)

@app.get("/disclosures")
def list_disclosures(db: Session = Depends(get_db)):
    ds = db.query(Disclosure).options(selectinload(Disclosure.lines)).order_by(Disclosure.id.desc()).all()
    return [disclosure_out(d) for d in ds]

@app.get("/disclosures/{did}")
def get_disclosure(did: int, db: Session = Depends(get_db)):
    d = db.query(Disclosure).options(selectinload(Disclosure.lines)).filter_by(id=did).first()
    if not d: raise HTTPException(404,"Disclosure not found")
    return disclosure_out(d)

@app.post("/disclosures/{did}/lines")
def add_line(did: int, payload: LineCreate, db: Session = Depends(get_db)):
    if not db.query(Disclosure).filter_by(id=did).first(): raise HTTPException(404,"Disclosure not found")
    try: amount = Decimal(payload.source_amount)
    except InvalidOperation: raise HTTPException(422,"source_amount must be a valid decimal")
    if not amount.is_finite(): raise HTTPException(422,"source_amount must be finite")
    line = DisclosureLine(disclosure_id=did,account_code=payload.account_code,label=payload.label,source_amount=str(amount),sort_order=payload.sort_order)
    db.add(line); audit(db,did,"LINE_ADDED",f"Added {payload.account_code}: {payload.label}")
    db.commit(); db.refresh(line)
    return line_out(line)

@app.post("/disclosures/{did}/round")
def round_disclosure(did: int, db: Session = Depends(get_db)):
    d = db.query(Disclosure).options(selectinload(Disclosure.lines)).filter_by(id=did).first()
    if not d: raise HTTPException(404,"Disclosure not found")
    if not d.lines: raise HTTPException(400,"Add at least one line before rounding")
    try:
        unit=Decimal(d.rounding_unit); amounts=[Decimal(x.source_amount) for x in d.lines]
        independent,balanced,adjustments,total=intelligent_balance(amounts,unit)
    except (InvalidOperation,ValueError) as e: raise HTTPException(422,str(e))
    for line,ind,bal,adj in zip(d.lines,independent,balanced,adjustments):
        line.independently_rounded=str(ind); line.balanced_amount=str(bal); line.adjustment=str(adj)
    audit(db,did,"ROUNDING_EXECUTED",f"Unit={unit}; balanced total={total}; lines={len(d.lines)}")
    db.commit(); db.refresh(d)
    out=disclosure_out(d); out["rounded_total"]=str(total)
    out["independently_rounded_total"]=str((sum(amounts,Decimal("0"))/unit).quantize(Decimal("1"),rounding=ROUND_HALF_UP)*unit)
    return out

@app.patch("/disclosures/{did}/status")
def set_status(did: int, payload: StatusUpdate, db: Session = Depends(get_db)):
    allowed={"DRAFT","IN_REVIEW","APPROVED","REJECTED"}
    if payload.status not in allowed: raise HTTPException(422,f"status must be one of {sorted(allowed)}")
    d=db.query(Disclosure).filter_by(id=did).first()
    if not d: raise HTTPException(404,"Disclosure not found")
    old=d.status; d.status=payload.status
    audit(db,did,"STATUS_CHANGED",f"{old} -> {payload.status}")
    db.commit()
    return {"id":d.id,"status":d.status}

@app.get("/disclosures/{did}/audit")
def get_audit(did: int, db: Session = Depends(get_db)):
    if not db.query(Disclosure).filter_by(id=did).first(): raise HTTPException(404,"Disclosure not found")
    events=db.query(AuditEvent).filter_by(disclosure_id=did).order_by(AuditEvent.id).all()
    return [{"id":e.id,"event_type":e.event_type,"detail":e.detail,"created_at":e.created_at.isoformat()} for e in events]

@app.post("/imports/file")
async def import_file(disclosure_id: int, file: UploadFile = File(...), db: Session = Depends(get_db)):
    if not db.query(Disclosure).filter_by(id=disclosure_id).first(): raise HTTPException(404,"Disclosure not found")
    try: rows=parse_upload(file.filename or "",await file.read())
    except Exception as e: raise HTTPException(422,str(e))
    for row in rows: db.add(DisclosureLine(disclosure_id=disclosure_id,**row))
    audit(db,disclosure_id,"FILE_IMPORTED",f"Imported {len(rows)} rows from {file.filename}")
    db.commit()
    return {"disclosure_id":disclosure_id,"imported":len(rows)}

@app.get("/disclosures/{did}/export.csv")
def export_csv(did: int, db: Session = Depends(get_db)):
    d=db.query(Disclosure).options(selectinload(Disclosure.lines)).filter_by(id=did).first()
    if not d: raise HTTPException(404,"Disclosure not found")
    buf=io.StringIO(); w=csv.writer(buf)
    w.writerow(["account_code","label","source_amount","independently_rounded","balanced_amount","adjustment"])
    for x in d.lines: w.writerow([x.account_code,x.label,x.source_amount,x.independently_rounded or "",x.balanced_amount or "",x.adjustment or ""])
    buf.seek(0)
    return StreamingResponse(iter([buf.getvalue()]),media_type="text/csv",headers={"Content-Disposition":f'attachment; filename="disclosure_{did}.csv"'})
