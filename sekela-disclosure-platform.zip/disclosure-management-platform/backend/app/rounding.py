from decimal import Decimal, ROUND_HALF_UP
from typing import Iterable

def D(value):
    return value if isinstance(value, Decimal) else Decimal(str(value))

def round_to_unit(value: Decimal, unit: Decimal) -> Decimal:
    if unit <= 0:
        raise ValueError("Rounding unit must be greater than zero")
    return (value / unit).quantize(Decimal("1"), rounding=ROUND_HALF_UP) * unit

def intelligent_balance(amounts: Iterable[Decimal], unit: Decimal):
    # Return independent line rounds, balanced line values, adjustments and total.
    values = [D(x) for x in amounts]
    unit = D(unit)
    if unit <= 0:
        raise ValueError("Rounding unit must be greater than zero")
    if not values:
        return [], [], [], Decimal("0")
    exact = [v / unit for v in values]
    independent_units = [x.quantize(Decimal("1"), rounding=ROUND_HALF_UP) for x in exact]
    target = (sum(values, Decimal("0")) / unit).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    residual = int(target - sum(independent_units))
    balanced_units = independent_units[:]
    if residual > 0:
        order = sorted(range(len(values)), key=lambda i: (-(exact[i] - independent_units[i]), i))
        step = 1
    elif residual < 0:
        order = sorted(range(len(values)), key=lambda i: ((exact[i] - independent_units[i]), i))
        step = -1
    else:
        order, step = [], 0
    for n in range(abs(residual)):
        balanced_units[order[n % len(order)]] += step
    independent = [x * unit for x in independent_units]
    balanced = [x * unit for x in balanced_units]
    adjustments = [b - i for b, i in zip(balanced, independent)]
    total = target * unit
    assert sum(balanced, Decimal("0")) == total
    return independent, balanced, adjustments, total
