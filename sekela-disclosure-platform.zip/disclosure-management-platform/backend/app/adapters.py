import csv, io, os
from decimal import Decimal
from typing import Any
import httpx
from openpyxl import load_workbook

REQUIRED = {"account_code", "label", "source_amount"}

def parse_upload(filename: str, content: bytes) -> list[dict[str, Any]]:
    ext = filename.lower().rsplit(".", 1)[-1]
    if ext == "csv":
        rows = list(csv.DictReader(io.StringIO(content.decode("utf-8-sig"))))
    elif ext in {"xlsx", "xlsm"}:
        wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
        data = list(wb.active.iter_rows(values_only=True))
        if not data:
            return []
        headers = [str(v).strip() if v is not None else "" for v in data[0]]
        rows = [dict(zip(headers, row)) for row in data[1:]]
    else:
        raise ValueError("Only CSV and XLSX files are supported")
    if not rows:
        return []
    missing = REQUIRED - set(rows[0])
    if missing:
        raise ValueError("Missing required columns: " + ", ".join(sorted(missing)))
    result = []
    for i, row in enumerate(rows, 1):
        if row.get("account_code") is None:
            continue
        result.append({"account_code": str(row["account_code"]).strip(),
                       "label": str(row["label"]).strip(),
                       "source_amount": str(Decimal(str(row["source_amount"]))),
                       "sort_order": int(row.get("sort_order") or i)})
    return result

class RestEPMClient:
    def __init__(self, base_url: str, headers=None):
        if not base_url:
            raise ValueError("Configure a base URL before connecting")
        self.base_url = base_url.rstrip("/")
        self.headers = headers or {}
    async def get_json(self, path: str):
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.get(f"{self.base_url}/{path.lstrip('/')}", headers=self.headers)
            r.raise_for_status()
            return r.json()

class OneStreamAdapter(RestEPMClient):
    @classmethod
    def from_env(cls):
        token = os.getenv("ONESTREAM_TOKEN", "")
        return cls(os.getenv("ONESTREAM_BASE_URL", ""), {"Authorization": f"Bearer {token}"} if token else {})

class OracleEPMAdapter(RestEPMClient):
    @classmethod
    def from_env(cls):
        return cls(os.getenv("ORACLE_EPM_BASE_URL", ""), {})
