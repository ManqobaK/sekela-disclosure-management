from datetime import datetime, timezone
from sqlalchemy import DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .database import Base

def now():
    return datetime.now(timezone.utc)

class Disclosure(Base):
    __tablename__ = "disclosures"
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(200))
    period: Mapped[str] = mapped_column(String(40))
    currency: Mapped[str] = mapped_column(String(3), default="ZAR")
    rounding_unit: Mapped[str] = mapped_column(String(40), default="1000")
    status: Mapped[str] = mapped_column(String(30), default="DRAFT")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    lines: Mapped[list["DisclosureLine"]] = relationship(back_populates="disclosure", cascade="all, delete-orphan", order_by="DisclosureLine.sort_order")

class DisclosureLine(Base):
    __tablename__ = "disclosure_lines"
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    disclosure_id: Mapped[int] = mapped_column(ForeignKey("disclosures.id"), index=True)
    account_code: Mapped[str] = mapped_column(String(80))
    label: Mapped[str] = mapped_column(String(250))
    source_amount: Mapped[str] = mapped_column(String(60))
    independently_rounded: Mapped[str | None] = mapped_column(String(60), nullable=True)
    balanced_amount: Mapped[str | None] = mapped_column(String(60), nullable=True)
    adjustment: Mapped[str | None] = mapped_column(String(60), nullable=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    disclosure: Mapped[Disclosure] = relationship(back_populates="lines")

class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    disclosure_id: Mapped[int] = mapped_column(ForeignKey("disclosures.id"), index=True)
    event_type: Mapped[str] = mapped_column(String(80))
    detail: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
