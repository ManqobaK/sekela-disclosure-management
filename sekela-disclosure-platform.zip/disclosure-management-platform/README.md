# SEKELA by LUSCON

**Intelligent disclosure management. Every number accounted for.**

SEKELA is an MVP financial disclosure workspace for preparing reporting packs, importing financial data, applying intelligent rounding and balancing, and moving disclosures through a basic review workflow. It is designed as a product foundation for Luscon.

## Product capabilities in this MVP

- Create disclosure packs by reporting period and currency.
- Add financial statement lines or import CSV/XLSX files.
- Preserve source values separately from presentation values.
- Apply Decimal-based `ROUND_HALF_UP` rounding and deterministic largest-remainder balancing.
- Review line-level independent rounding, balanced values and adjustments.
- Move a pack through Draft, In Review, Approved and Rejected statuses.
- Maintain an event audit trail and export disclosure lines to CSV.
- Provide generic REST client foundations for OneStream and Oracle EPM.

## Architecture

| Layer | Technology |
|---|---|
| Web UI | React 18 + Vite |
| API | Python 3.11+ + FastAPI + Pydantic |
| Persistence | SQLAlchemy 2; SQLite locally / PostgreSQL in Docker |
| Financial arithmetic | Python `Decimal` |
| Import | CSV + XLSX (`openpyxl`) |
| Integration foundation | HTTPX REST client |
| Tests | pytest |

## Repository layout

```text
sekela-disclosure-platform/
├── assets/sekela-mark.svg
├── backend/app/                 # FastAPI API, models, rounding and adapters
├── backend/tests/               # Rounding engine tests
├── frontend/                    # React/Vite application
├── sample-data/                 # Example disclosure import file
├── docker-compose.yml
├── Dockerfile
├── pytest.ini
└── README.md
```

## Run locally

### 1. API

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload --app-dir backend
```

API health: http://localhost:8000/health  
Interactive API docs: http://localhost:8000/docs

### 2. Web application

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173. The frontend expects the API at `http://localhost:8000` by default. Set `VITE_API_URL` if it is hosted elsewhere.

### 3. Run with Docker

```bash
docker compose up --build
```

The compose stack starts the API and PostgreSQL. The React frontend is run separately using the commands above.

## Tests

```bash
pytest -q
```

The tests cover aggregate balancing, deterministic allocation, negative values, empty input and half-up rounding. A passing local test run is not a substitute for finance-policy validation.

## Import format

Upload CSV or XLSX via `POST /imports/file?disclosure_id=<id>`. Required columns:

- `account_code`
- `label`
- `source_amount`
- `sort_order` (optional)

A sample is provided at `sample-data/disclosure-lines.csv`.

## API quick start

Create a disclosure:

```bash
curl -X POST http://localhost:8000/disclosures \
  -H 'Content-Type: application/json' \
  -d '{"name":"Annual Financial Results","period":"FY2026","currency":"ZAR","rounding_unit":"1000"}'
```

Add a line (replace `1` with the returned ID):

```bash
curl -X POST http://localhost:8000/disclosures/1/lines \
  -H 'Content-Type: application/json' \
  -d '{"account_code":"REV001","label":"Revenue","source_amount":"1245600","sort_order":1}'
```

Run rounding:

```bash
curl -X POST http://localhost:8000/disclosures/1/round
```

## Rounding and balancing logic

SEKELA independently rounds each line to the configured unit, rounds the aggregate source total, then allocates the difference in whole rounding units using a deterministic largest-remainder approach. It stores source amounts, independently rounded amounts, balanced amounts and adjustments separately. The engine asserts that balanced lines sum exactly to the rounded aggregate.

**Policy note:** this is one configurable-method foundation, not a universal accounting rule. The finance owner must approve the allocation policy, sign convention, materiality and presentation rules for each reporting use case.

## OneStream and Oracle EPM integration status

The current `OneStreamAdapter` and `OracleEPMAdapter` are generic REST foundations only. No live connection, vendor-specific authentication, data extraction, write-back or certification is included. Before implementing a production connector, confirm the customer's OneStream/Oracle EPM version, licensed APIs, authentication model, endpoint documentation, data format, dimensions, application/cube, and security roles. The MVP does not write back to either platform.

## Current workflow limitations

The MVP has basic status transitions and an audit event log. It does not yet enforce maker-checker separation, user identity, role-based permissions, immutable audit storage or segregation of duties. Do not treat the current status endpoint as a controlled approval process.

## Production roadmap

1. Authentication, SSO, RBAC and maker-checker approvals.
2. Configurable rounding policies with effective dates, versioning and test scenarios.
3. Validated OneStream and Oracle EPM connectors with secure secret handling and idempotent ingestion.
4. Disclosure templates, mappings, comparative periods and reconciliation rules.
5. Excel, Word and PDF publication with versioned outputs.
6. Multi-entity tenancy, PostgreSQL migrations, encryption, backups, monitoring and audit hardening.
7. Finance, audit and regulatory validation before production use.

## Important

This repository is a development MVP, not a production-certified statutory reporting system. It has no production authentication or authorization. Use synthetic data until security, controls, integrations and accounting policies have been reviewed and approved.

## Brand

**SEKELA** is the product name; **LUSCON** is the parent brand. The supplied SVG is a starter mark, not a completed trademark or brand clearance. Check CIPC, domain and relevant software trademark availability before commercial launch.
